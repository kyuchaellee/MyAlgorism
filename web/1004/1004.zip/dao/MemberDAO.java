package org.zerock.w0929.dao;

import org.zerock.w0929.dto.MemberDTO;

public enum MemberDAO {

    INSTANCE;

    public MemberDTO login(String mid, String mpw){
        return null;
    }
}
