package variable;

import java.util.Scanner;

public class Application2_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("문자 : ");
		char a = sc.nextLine().charAt(0);
		System.out.println(a + " Unicode: " + (int)a);
		
		
	}

}
